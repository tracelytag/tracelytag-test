using TracelyTagAPI.Controllers;
using TracelyTagAPI.Data;
using TracelyTagAPI.Interface;
using TracelyTagAPI.Models;
using TracelyTagAPI.Repository;
namespace TracelyTagAPI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();


            builder.Services.AddSingleton<DapperContext>();
            builder.Services.AddTransient<IProduct, ProductRepository>();
            builder.Services.AddTransient<IBatch, BatchRepository>();
            builder.Services.AddTransient<ICompany, CompanyRepository>();
            builder.Services.AddTransient<IQr, QrRepository>();


            //builder.Services.AddSwaggerGen();
            builder.Services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "TracelyTagAPI",
                    Version = "v1"
                });
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
