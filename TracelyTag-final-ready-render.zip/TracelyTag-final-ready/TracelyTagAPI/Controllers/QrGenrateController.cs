﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TracelyTagAPI.Interface;
using TracelyTagAPI.Models;

namespace TracelyTagAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QrGenrateController : ControllerBase
    {
        private readonly IQr _Qr;
        public QrGenrateController(IQr qrrepo)
        {
            _Qr = qrrepo;
        }
        [HttpPost("InsertQrDetails")]
        public async Task<IActionResult> InsertQrDetails([FromBody] QrGenrateModel model)
        {
            var response = await _Qr.InsertQrDetails(model);
            return Ok(response);
        }
        [HttpGet("QrList")]
        public async Task<IActionResult> QrList()
        {
            var response = await _Qr.QrList();
            return Ok(response);
        }
    }
}
