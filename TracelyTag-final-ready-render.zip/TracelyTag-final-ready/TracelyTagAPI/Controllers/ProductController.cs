﻿using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Threading.Tasks;
using TracelyTagAPI.Interface;
using TracelyTagAPI.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace TracelyTagAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProduct _Product;
        public ProductController(IProduct productrepo)
        {
            _Product = productrepo;
        }
        [HttpPost("InsertProduct")]
        public async Task<IActionResult> InsertProduct([FromBody] ProductEntryModel model)
        {
            var response = await _Product.InsertProduct(model);
            return Ok(response);
        }
        [HttpGet("GetAllProduct")]
        public async Task<IActionResult> GetAllProduct()
        {
            var response = await _Product.GetAllProduct();
            return Ok(response);
        }
    }
}
