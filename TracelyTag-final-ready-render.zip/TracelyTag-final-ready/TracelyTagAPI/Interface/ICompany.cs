﻿using TracelyTagAPI.Models;

namespace TracelyTagAPI.Interface
{
    public interface ICompany
    {
        Task<IEnumerable<CompanyModel>> InsertCompanyDetails(CompanyModel model);
    }
}
