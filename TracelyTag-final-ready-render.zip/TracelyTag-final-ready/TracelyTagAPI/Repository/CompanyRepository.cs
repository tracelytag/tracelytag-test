﻿using Dapper;
using Microsoft.Data.SqlClient;
using System.Data;
using TracelyTagAPI.Data;
using TracelyTagAPI.Interface;
using TracelyTagAPI.Models;

namespace TracelyTagAPI.Repository
{
    public class CompanyRepository : ICompany
    {
        private readonly DapperContext _context;
        public CompanyRepository(DapperContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<CompanyModel>> InsertCompanyDetails(CompanyModel model)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@CompanyName", model.CompanyName);
                parameters.Add("@CompanyDetails", model.CompanyDetails);
                parameters.Add("@GstNo", model.GstNo);
                parameters.Add("@ExpiryDate", model.ExpiryDate);

                using (var connection = _context.CreateConnection())
                {
                    var companyList = await connection.QueryAsync<CompanyModel>(
                        "Sp_InsertCompanyDetails",
                        parameters,
                        commandType: CommandType.StoredProcedure,
                        commandTimeout: 0);

                    return companyList.ToList();
                }
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine($"SQL Error: {sqlEx.Message}");
                return new List<CompanyModel>();
            }
            catch (Exception ex)
            {
                // Handle unexpected errors
                Console.WriteLine($"General Error: {ex.Message}");

                return new List<CompanyModel>();
            }
        }
    }
}
