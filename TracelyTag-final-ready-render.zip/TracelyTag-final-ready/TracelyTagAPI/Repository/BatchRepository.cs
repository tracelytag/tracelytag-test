﻿using Dapper;
using Microsoft.Data.SqlClient;
using System.Data;
using TracelyTagAPI.Data;
using TracelyTagAPI.Interface;
using TracelyTagAPI.Models;

namespace TracelyTagAPI.Repository
{
    public class BatchRepository : IBatch
    {
        private readonly DapperContext _context;
        public BatchRepository(DapperContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<BatchEntryModel>> InsertBatch(BatchEntryModel model)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@BatchNo", model.BatchNo);
                parameters.Add("@ProductId", model.Productid);

                using (var connection = _context.CreateConnection())
                {
                    var batchList = await connection.QueryAsync<BatchEntryModel>(
                        "Sp_InsertbatchDetails",
                        parameters,
                        commandType: CommandType.StoredProcedure,
                        commandTimeout: 0);

                    return batchList.ToList();
                }
            }
            catch (SqlException sqlEx)
            {
                // Handle SQL-specific errors (e.g., login issues, timeouts)
                Console.WriteLine($"SQL Error: {sqlEx.Message}");

                // Return empty list or rethrow, depending on your requirement
                return new List<BatchEntryModel>();
            }
            catch (Exception ex)
            {
                // Handle unexpected errors
                Console.WriteLine($"General Error: {ex.Message}");

                return new List<BatchEntryModel>();
            }
        }

        public async Task<IEnumerable<BatchEntryModel>> GetAllBatch()
        {
            try
            {
                using (var connection = _context.CreateConnection())
                {
                    var batchList = await connection.QueryAsync<BatchEntryModel>(
                        "Sp_GetAllBatch",
                        commandType: CommandType.StoredProcedure,
                        commandTimeout: 0);

                    return batchList.ToList();
                }
            }
            catch (SqlException sqlEx)
            {
                // Handle SQL-specific errors (e.g., login issues, timeouts)
                Console.WriteLine($"SQL Error: {sqlEx.Message}");

                // Return empty list or rethrow, depending on your requirement
                return new List<BatchEntryModel>();
            }
            catch (Exception ex)
            {
                // Handle unexpected errors
                Console.WriteLine($"General Error: {ex.Message}");

                return new List<BatchEntryModel>();
            }
        }
    }
}
