﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Reflection;
using TracelyTagWeb.Models;
using ZXing;
using ZXing.Common;
using ZXing.Datamatrix;
using SkiaSharp;
using System.IO;
using System.Runtime.InteropServices;

namespace TracelyTagWeb.Controllers
{
    public class QrGenrateController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;

        public QrGenrateController(IConfiguration configuration)
        {
            _configuration = configuration;
            //_httpClient = new HttpClient();
            _httpClient = new HttpClient
            {
                BaseAddress = new Uri(_configuration["ApiSettings:BaseUrl"])
            };

        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> GenrateQr(QrGenrateModel model)
        {
            TracelyTagMainModel ListModel = new TracelyTagMainModel();
            try
            {
                var response = await _httpClient.PostAsJsonAsync($"QrGenrate/InsertQrDetails", model);
                return RedirectToAction("QrView", "QrGenrate");
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    error = ex.ToString(),
                    stack = ex.StackTrace,
                    message = ex.Message,
                    //res = response
                });
            }
            return View();
        }
        [HttpGet]
        public async Task<IActionResult> QrView()
        {
            TracelyTagMainModel ListModel = new TracelyTagMainModel();

            var getqrlist = await _httpClient.GetAsync($"QrGenrate/QrList");
            if (getqrlist.IsSuccessStatusCode)
            {
                var content = await getqrlist.Content.ReadAsStringAsync();
                ListModel.QrList = JsonConvert.DeserializeObject<List<QrGenrateModel>>(content);
            }
            return View(ListModel.QrList);
        }
        [HttpGet]
        public IActionResult GenerateDataMatrix(string qrString)
        {
            if (string.IsNullOrEmpty(qrString))
                return BadRequest("QR string is empty.");

            var writer = new ZXing.BarcodeWriterPixelData
            {
                Format = BarcodeFormat.DATA_MATRIX,
                Options = new EncodingOptions
                {
                    Height = 200,
                    Width = 200,
                    Margin = 1,
                    PureBarcode = true
                }
            };

            var pixelData = writer.Write(qrString);
            var info = new SKImageInfo(pixelData.Width, pixelData.Height, SKColorType.Bgra8888);

            // 👇 Pin the byte[] to get its memory address
            var handle = GCHandle.Alloc(pixelData.Pixels, GCHandleType.Pinned);
            try
            {
                IntPtr ptr = handle.AddrOfPinnedObject();
                using var pixmap = new SKPixmap(info, ptr, info.RowBytes);
                using var image = SKImage.FromPixels(pixmap);
                using var data = image.Encode(SKEncodedImageFormat.Png, 100);

                using var ms = new MemoryStream();
                data.SaveTo(ms);
                return File(ms.ToArray(), "image/png");
            }
            finally
            {
                handle.Free();
            }
        }

        [HttpGet]
        public IActionResult ScanResult(string code)
        {
            if (string.IsNullOrEmpty(code))
                return Content("Invalid QR Code.");

            //using (var context = new YourDbContext()) // replace with your actual DbContext
            //{
            //    // 🔍 Find the product by QR code
            //    var product = context.Products.FirstOrDefault(x => x.QrCode == code);

            //    if (product == null)
            //    {
            //        return Content("No product found for this QR code.");
            //    }

            //    // 💾 Save scan history
            //    var scan = new QrScanHistory
            //    {
            //        ProductId = product.Id,
            //        ScanTime = DateTime.Now
            //    };
            //    context.QrScanHistories.Add(scan);
            //    context.SaveChanges();

            //    // ✅ Pass product info to the view
            //    ViewBag.ProductName = product.ProductName;
            //    ViewBag.ProductDetails = product.ProductDetails;
            //    ViewBag.BatchName = product.BatchName;
            //    ViewBag.Message = "QR Scanned Successfully!";

            //    return View();
            //}
            return View();
        }

    }

}

