﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using TracelyTagWeb.Models;

namespace TracelyTagWeb.Controllers
{
    public class ProductController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;

        public ProductController(IConfiguration configuration)
        {
            _configuration = configuration;
            //_httpClient = new HttpClient();
            _httpClient = new HttpClient
            {
                BaseAddress = new Uri(_configuration["ApiSettings:BaseUrl"])
            };

        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> InsertProduct(ProductEntryModel model)
        {
            TracelyTagMainModel ListModel = new TracelyTagMainModel();
            try
            {
                //Insert Product API
                var response = await _httpClient.PostAsJsonAsync($"Product/InsertProduct", model);
                return RedirectToAction("BatchEntry","Product");
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    error = ex.ToString(),
                    stack = ex.StackTrace,
                    message = ex.Message,
                    //res = response
                });
            }
        }
        public async Task<IActionResult> BatchEntry()
        {
            TracelyTagMainModel ListModel = new TracelyTagMainModel();

            //Get All Product Details API
            var getproductres = await _httpClient.GetAsync("Product/GetAllProduct");
            if (getproductres.IsSuccessStatusCode)
            {
                var content = await getproductres.Content.ReadAsStringAsync();
                ListModel.GetProductList = JsonConvert.DeserializeObject<List<ProductEntryModel>>(content);
            }
            return View(ListModel);
        }
       
    }
}
