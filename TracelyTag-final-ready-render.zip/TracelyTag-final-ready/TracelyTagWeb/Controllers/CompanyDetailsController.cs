﻿using Microsoft.AspNetCore.Mvc;
using TracelyTagWeb.Models;
using System.Net.Http;

namespace TracelyTagWeb.Controllers
{
    public class CompanyDetailsController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;

        public CompanyDetailsController(IConfiguration configuration)
        {
            _configuration = configuration;
            //_httpClient = new HttpClient();
            _httpClient = new HttpClient
            {
                BaseAddress = new Uri(_configuration["ApiSettings:BaseUrl"])
            };

        }
        public IActionResult Index()
        {
            return View("CompanyDetails");
        }
        [HttpPost]
        public async Task<IActionResult> InsertCompanyDetails(CompanyModel model)
        {
            TracelyTagMainModel ListModel = new TracelyTagMainModel();
            try
            {
                //Insert Product API
                var response = await _httpClient.PostAsJsonAsync($"CompanyDetails/InsertCompanyDetails", model);
                return RedirectToAction("Index", "Product");
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    error = ex.ToString(),
                    stack = ex.StackTrace,
                    message = ex.Message,
                    //res = response
                });
            }
        }
    }
}
