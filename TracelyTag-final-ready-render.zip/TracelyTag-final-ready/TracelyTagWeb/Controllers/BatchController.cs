﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using TracelyTagWeb.Models;

namespace TracelyTagWeb.Controllers
{
    public class BatchController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;

        public BatchController(IConfiguration configuration)
        {
            _configuration = configuration;
            _httpClient = new HttpClient
            {
                BaseAddress = new Uri(_configuration["ApiSettings:BaseUrl"])
            };

        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> InsertBatch(BatchEntryModel model)
        {
            TracelyTagMainModel ListModel = new TracelyTagMainModel();
            try
            {
                var response = await _httpClient.PostAsJsonAsync($"Batch/InsertBatch", model);
               
                return RedirectToAction("QrGenrate","Batch");
            }
            catch (Exception ex)
            {
                return Json(new
                {
                    error = ex.ToString(),
                    stack = ex.StackTrace,
                    message = ex.Message,
                    //res = response
                });
            }
        }

        public async Task<IActionResult> QrGenrate()
        {
            TracelyTagMainModel ListModel = new TracelyTagMainModel();

            var getbatch = await _httpClient.GetAsync("Batch/GetAllBatch");
            if (getbatch.IsSuccessStatusCode)
            {
                var content = await getbatch.Content.ReadAsStringAsync();
                ListModel.GetBatchList = JsonConvert.DeserializeObject<List<BatchEntryModel>>(content);
            }
            var getproductres = await _httpClient.GetAsync("Product/GetAllProduct");
            if (getproductres.IsSuccessStatusCode)
            {
                var content = await getproductres.Content.ReadAsStringAsync();
                ListModel.GetProductList = JsonConvert.DeserializeObject<List<ProductEntryModel>>(content);
            }
            return View(ListModel);
        }
    }
}
