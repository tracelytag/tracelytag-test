﻿using TracelyTagAPI.Models;

namespace TracelyTagAPI.Interface
{
    public interface IQr
    {
        Task<IEnumerable<QrGenrateModel>> InsertQrDetails(QrGenrateModel model);
        Task<IEnumerable<QrGenrateModel>> QrList();
    }
}
