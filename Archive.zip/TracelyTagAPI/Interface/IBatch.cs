﻿using TracelyTagAPI.Models;

namespace TracelyTagAPI.Interface
{
    public interface IBatch
    {
        Task<IEnumerable<BatchEntryModel>> InsertBatch(BatchEntryModel model);
        Task<IEnumerable<BatchEntryModel>> GetAllBatch();
    }
}
