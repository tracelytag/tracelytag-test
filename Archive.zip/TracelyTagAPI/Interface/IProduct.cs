﻿using TracelyTagAPI.Models;

namespace TracelyTagAPI.Interface
{
    public interface IProduct
    {
        Task<IEnumerable<ProductEntryModel>> InsertProduct(ProductEntryModel model);
        Task<IEnumerable<ProductEntryModel>> GetAllProduct();
    }
}
