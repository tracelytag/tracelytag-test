﻿using Dapper;
using Microsoft.Data.SqlClient;
using System.Data;
using TracelyTagAPI.Data;
using TracelyTagAPI.Interface;
using TracelyTagAPI.Models;

namespace TracelyTagAPI.Repository
{
    public class QrRepository : IQr
    {
        private readonly DapperContext _context;
        public QrRepository(DapperContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<QrGenrateModel>> InsertQrDetails(QrGenrateModel model)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@ProductId", model.Productid);
                parameters.Add("@BatchId", model.BatchId);
                parameters.Add("@QrSize", model.QrSize);

                using (var connection = _context.CreateConnection())
                {
                    var qrList = await connection.QueryAsync<QrGenrateModel>(
                        "Sp_InsertQrDetails",
                        parameters,
                        commandType: CommandType.StoredProcedure,
                        commandTimeout: 0);

                    return qrList.ToList();
                }
            }
            catch (SqlException sqlEx)
            {
                // Handle SQL-specific errors (e.g., login issues, timeouts)
                Console.WriteLine($"SQL Error: {sqlEx.Message}");

                // Return empty list or rethrow, depending on your requirement
                return new List<QrGenrateModel>();
            }
            catch (Exception ex)
            {
                // Handle unexpected errors
                Console.WriteLine($"General Error: {ex.Message}");

                return new List<QrGenrateModel>();
            }
        }

        public async Task<IEnumerable<QrGenrateModel>> QrList()
        {
            try
            {
                using (var connection = _context.CreateConnection())
                {
                    var QrList = await connection.QueryAsync<QrGenrateModel>(
                        "Sp_GetQrList",
                        commandType: CommandType.StoredProcedure,
                        commandTimeout: 0);

                    return QrList.ToList();
                }
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine($"SQL Error: {sqlEx.Message}");
                return new List<QrGenrateModel>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"General Error: {ex.Message}");
                return new List<QrGenrateModel>();
            }
        }
    }
}
