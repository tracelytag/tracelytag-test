﻿using Dapper;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;
using TracelyTagAPI.Data;
using TracelyTagAPI.Interface;
using TracelyTagAPI.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace TracelyTagAPI.Repository
{
    public class ProductRepository : IProduct
    {
        private readonly DapperContext _context;
        public ProductRepository(DapperContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<ProductEntryModel>> InsertProduct(ProductEntryModel model)
        {
            try
            {
                var parameters = new DynamicParameters();
                parameters.Add("@ProductName", model.ProductName);
                parameters.Add("@ProductDetails", model.ProductDetails);
                parameters.Add("@ShipperSize", model.ShipperSize);
                parameters.Add("@PaletSize", model.PaletSize);

                using (var connection = _context.CreateConnection())
                {
                    var productsList = await connection.QueryAsync<ProductEntryModel>(
                        "Sp_InsertProductDetails",
                        parameters,
                        commandType: CommandType.StoredProcedure,
                        commandTimeout: 0);

                    return productsList.ToList();
                }
            }
            catch (SqlException sqlEx)
            {
                // Handle SQL-specific errors (e.g., login issues, timeouts)
                Console.WriteLine($"SQL Error: {sqlEx.Message}");

                // Return empty list or rethrow, depending on your requirement
                return new List<ProductEntryModel>();
            }
            catch (Exception ex)
            {
                // Handle unexpected errors
                Console.WriteLine($"General Error: {ex.Message}");

                return new List<ProductEntryModel>();
            }
        }
        public async Task<IEnumerable<ProductEntryModel>> GetAllProduct()
        {
            try
            {
                using (var connection = _context.CreateConnection())
                {
                    var productsList = await connection.QueryAsync<ProductEntryModel>(
                        "Sp_GetProduct",
                        commandType: CommandType.StoredProcedure,
                        commandTimeout: 0);

                    return productsList.ToList();
                }
            }
            catch (SqlException sqlEx)
            {
                // Handle SQL-specific errors (e.g., login issues, timeouts)
                Console.WriteLine($"SQL Error: {sqlEx.Message}");

                // Return empty list or rethrow, depending on your requirement
                return new List<ProductEntryModel>();
            }
            catch (Exception ex)
            {
                // Handle unexpected errors
                Console.WriteLine($"General Error: {ex.Message}");

                return new List<ProductEntryModel>();
            }
        }
    }
}

