﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using TracelyTagAPI.Interface;
using TracelyTagAPI.Models;

namespace TracelyTagAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BatchController : ControllerBase
    {
        private readonly IBatch _Batch;
        public BatchController(IBatch batchrepo)
        {
            _Batch = batchrepo;
        }

        [HttpPost("InsertBatch")]
        public async Task<IActionResult> InsertBatch([FromBody] BatchEntryModel model)
        {
            var response = await _Batch.InsertBatch(model);
            return Ok(response);
        }
        [HttpGet("GetAllBatch")]
        public async Task<IActionResult> GetAllBatch()
        {
            var response = await _Batch.GetAllBatch();
            return Ok(response);
        }
    }
}
