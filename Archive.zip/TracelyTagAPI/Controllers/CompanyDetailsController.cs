﻿using Microsoft.AspNetCore.Mvc;
using TracelyTagAPI.Interface;
using TracelyTagAPI.Models;

namespace TracelyTagAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyDetailsController : ControllerBase
    {
        private readonly ICompany _Company;
        public CompanyDetailsController(ICompany companyrepo)
        {
            _Company = companyrepo;
        }
        [HttpPost("InsertCompanyDetails")]
        public async Task<IActionResult> InsertCompanyDetails([FromBody] CompanyModel model)
        {
            var response = await _Company.InsertCompanyDetails(model);
            return Ok(response);
        }
    }
}
