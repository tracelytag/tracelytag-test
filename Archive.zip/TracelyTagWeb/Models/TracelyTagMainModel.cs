﻿namespace TracelyTagWeb.Models
{
    public class TracelyTagMainModel
    {
        public TracelyTagMainModel()
        {
            ProductEntry = new ProductEntryModel();
            GetProductList = new List<ProductEntryModel>();
            BatchEntry = new BatchEntryModel();
            GetBatchList = new List<BatchEntryModel>();
            CompanyEntry = new CompanyModel();
            QrGenrate = new QrGenrateModel();
            QrList = new List<QrGenrateModel>();
        }
        public ProductEntryModel ProductEntry { get; set; }
        public List<ProductEntryModel> GetProductList { get; set; }
        public BatchEntryModel BatchEntry { get; set; }
        public List<BatchEntryModel> GetBatchList { get; set; }
        public CompanyModel CompanyEntry { get; set; }
        public QrGenrateModel QrGenrate { get; set; }
        public List<QrGenrateModel> QrList { get; set; }
    }
    public class ProductEntryModel
    {
        public int Productid { get; set; }
        public string ProductName { get; set; }
        public string ProductDetails { get; set; }
        public int ShipperSize { get; set; }
        public int PaletSize { get; set; }
    }
    public class BatchEntryModel
    {
        public int BatchId { get; set; }
        public string BatchNo { get; set; }
        public int Productid { get; set; }
    }
    public class CompanyModel
    {
        public string CompanyName { get; set; }
        public string CompanyDetails { get; set; }
        public string GstNo { get; set; }
        public DateTime ExpiryDate { get; set; }
    }
    public class QrGenrateModel
    {
        public int Productid { get; set; }
        public int BatchId { get; set; }
        public int QrSize { get; set; }
        public string Qrstring { get; set; } = string.Empty;
    }
}
